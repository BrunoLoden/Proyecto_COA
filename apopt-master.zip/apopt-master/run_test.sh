python apopt.py hs001.nl
